const sentence = 'The sun will shine on us again';
console.log(sentence.slice(13));
console.log(sentence.slice(13, 24));
console.log(sentence.slice(0));
console.log(sentence.slice(0, -23));
console.log(sentence.slice(50));
console.log(sentence.slice(7, 2));