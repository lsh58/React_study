const obj = {
    movie: 'Sunny',
    music: 'Like Sugar',
    style: 'Retro',
    price: Infinity
};

const modifiedObj = Object.entries(obj);
console.log(modifiedObj);