const str = 'Good afternoon, Good evening, and Good night! ' 
    + '- The Truman Show, 1998';

console.log(str.charAt(0));
console.log(str.charAt(5));
console.log(str.charAt(14));
console.log(str.length);
console.log(str.charAt(500));