const festa = ['mang'];
festa.unshift('chimmy');
festa.unshift('tata')
festa.unshift('cooky');
festa.unshift('shooky');
festa.unshift('koya');
festa.unshift('rj');

festa.forEach(name => {
    console.log(name);
});