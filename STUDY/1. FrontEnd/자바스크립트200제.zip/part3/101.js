const obj = {
    movie: 'Sunny',
    music: 'Like Sugar',
    style: 'Retro',
    price: Infinity
};

const arr = Object.keys(obj);

console.log(arr);