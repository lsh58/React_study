const str = 'Make your lives extradordinary';

console.log(str.includes('Make'));
console.log(str.includes('Make', 1));