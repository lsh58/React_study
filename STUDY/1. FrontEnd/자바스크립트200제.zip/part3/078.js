console.log('Find Your Own Voice'.toLowerCase());
console.log('Find Your Own Voice'.toUpperCase());

const value = 'Find Your Own Voice';
console.log(value.toLowerCase() === value.toUpperCase());