const festa = ['mang'];
festa.push('chimmy');
festa.push('tata')
festa.push('cooky');
festa.push('shooky');
festa.push('koya');
festa.push('rj');

festa.forEach(name => {
    console.log(name);
});