setTimeout(() => {
	console.log('JavaScript');
}, 0);

console.log('200제');