const positiveNum = 93.54;
const negativeNum = -39.27;

console.log(Math.ceil(positiveNum));
console.log(Math.ceil(negativeNum));
console.log(Math.ceil(positiveNum * 10) / 10);
console.log(Math.ceil(positiveNum / 10) * 10);
console.log(Math.ceil(negativeNum * 10) / 10);
console.log(Math.ceil(negativeNum / 10) * 10);