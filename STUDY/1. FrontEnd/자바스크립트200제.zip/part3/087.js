const arr = [1, 2, 3];
console.log(arr.shift());
console.log(arr.shift());
console.log(arr.shift());
console.log(arr.shift());