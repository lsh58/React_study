const sentence = 'Wakanda Forever!!!';
console.log(sentence.substr(8));
console.log(sentence.substr(8, 7));
console.log(sentence.substr(0));
console.log(sentence.substr(-10));
console.log(sentence.substr(0, -3));
console.log(sentence.substr(30));
console.log(sentence.substr(0, 30));