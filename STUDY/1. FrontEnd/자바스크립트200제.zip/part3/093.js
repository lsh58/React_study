const str = 'abcdefghijklmnopqrstuvwxyz';
const arr = str.split('');
arr.reverse();

console.log(arr.join(''));