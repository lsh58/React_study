console.log(parseInt('15'));
console.log(parseInt('15', 10));
console.log(parseInt('15', 2));
console.log(parseInt(5.15));
console.log(parseInt('5.15'));