console.log(parseFloat(5.55));
console.log(parseFloat('5.55'));
console.log(parseFloat('5.55 숫자의 결과값'));