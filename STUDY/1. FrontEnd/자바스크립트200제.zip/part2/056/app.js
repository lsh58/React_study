import { hello } from './hello.js';

hello('es6 module');