import Hello from './hello.js';

const koreanHi = new Hello('안녕하세요.');
koreanHi.hi('하린');
