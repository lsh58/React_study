console.log(5 > 3);
console.log(5 < 3);
console.log(5 <= 6);
console.log(5 >= 5);