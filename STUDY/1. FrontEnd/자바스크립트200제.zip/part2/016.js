console.log(Infinity); /* Infinity */ 
console.log(1 / Infinity); /* 0 */
console.log(0 / 0); /* NaN */
console.log(Infinity - Infinity); /* NaN */
console.log(0 / "말도 안되는 값"); /* NaN */
