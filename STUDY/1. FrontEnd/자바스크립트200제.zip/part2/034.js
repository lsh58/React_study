var greeting_expression = function(name) {
	console.log('Hi, ' + name);
}

function greeting_declaration(name) {
    console.log('Hi, ' + name);
}

greeting_expression('Chloe');
greeting_declaration('Chloe');