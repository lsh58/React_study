const URL = 'http://js.com';
URL = 'http://js.com';

if (true) {
  const URL2 = 'http://js.com'; 
}

console.log(URL2);