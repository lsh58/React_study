console.log("I'm in jeju");
console.log('Sewha ocean is wonderful');
console.log(`Have you ever eaten Makgeolli?`);
console.log("This is the first line\nAnd this is the second");
