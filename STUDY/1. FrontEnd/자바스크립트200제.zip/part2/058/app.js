import { add, Person, personA, version } from './hello.js';

const result = add(1, 2);
const harin = new Person('하린');

console.log(result);
console.log(harin.name);
console.log(version);