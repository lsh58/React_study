console.log('hello!');
window.hello = function hello(name) {
  console.log('hello ' + name);
}