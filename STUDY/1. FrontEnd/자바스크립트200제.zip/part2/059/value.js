export let value = 1;

setTimeout(() => {
  value++;
}, 1000);
