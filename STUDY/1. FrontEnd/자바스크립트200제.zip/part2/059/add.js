export default function add(a, b) {
  return a + b;
}
export const version = 'v1.0';
