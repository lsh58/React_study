import { value } from './value.js';

console.log(value);

setTimeout(() => console.log(value), 2000);
