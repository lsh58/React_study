import { version as moduleVersion } from './version.js';

const version = 'v0';
console.log(moduleVersion);
