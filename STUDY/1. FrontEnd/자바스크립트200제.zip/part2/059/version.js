export const version = 'v1.0';
