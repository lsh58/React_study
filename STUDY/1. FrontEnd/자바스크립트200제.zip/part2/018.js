console.log(7 > 3);
console.log(7 < 3);