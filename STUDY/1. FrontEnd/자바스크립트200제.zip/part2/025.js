console.log(14 & 11);
console.log(~14);
console.log(14 | 11);
console.log(14 ^ 11);
console.log(2 << 2);
console.log(14 >> 1);
console.log(14 >>> 2);