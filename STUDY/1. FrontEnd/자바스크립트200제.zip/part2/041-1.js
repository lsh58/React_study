let value = "바깥값";
if (true) {
  console.log(value);
  let value = "안쪽값";
}