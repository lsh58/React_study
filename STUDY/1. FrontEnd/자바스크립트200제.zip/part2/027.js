var arr = [1, 2, 3, 4, 5];
console.log(arr.length);
console.log(arr[0]);
console.log(arr[2]);
console.log(arr[8]);