console.log(15 % 4);
console.log(3 ** 3);
console.log(+10);
console.log(-10);
var value = 10;
++value;
--value;
console.log(value);