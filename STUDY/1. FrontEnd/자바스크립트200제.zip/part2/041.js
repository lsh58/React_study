if (true) {
  var functionScopeValue = 'global';
  let blockScopeValue = 'local';
}
console.log(functionScopeValue); 
console.log(blockScopeValue);