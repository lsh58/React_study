var value = null;
console.log(value);
console.log(typeof value);
var value;
console.log(value);
console.log(typeof value);