// AND 논리 연산자 &&
console.log(true && true);
console.log(true && false);
console.log('문장' == '문장' && 5 == 5);
console.log(5 == 5 && '다른문장 1' == '다른문장 2');

// Or 논리 연산자 ||
console.log(true || false);
console.log(false || false);
console.log('문장' == '문장' || 5 == 10);

// Not 논리 연산자 !
console.log(!true);
console.log(!false);
console.log(!5);
console.log(!'문장');
console.log(!!5);
console.log(!!'문장');