const greet = require('./greet.js');

greet('JavaScript 200');