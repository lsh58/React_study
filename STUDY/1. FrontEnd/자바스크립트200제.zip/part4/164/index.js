const moduleTest = require('./moduleTest');

console.log(moduleTest(3, 7));