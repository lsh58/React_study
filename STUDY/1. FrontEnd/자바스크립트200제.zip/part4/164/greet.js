console.log('Hello');

const greet = function(name) {
  console.log('How are you? ' + name);
};

module.exports = greet;