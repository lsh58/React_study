function moduleTest (x, y) {
  return x + y;
}

module.exports = moduleTest;