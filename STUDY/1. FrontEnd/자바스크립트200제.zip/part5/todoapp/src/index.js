import { TodoApp } from './app2.js';

const todoApp = new TodoApp();