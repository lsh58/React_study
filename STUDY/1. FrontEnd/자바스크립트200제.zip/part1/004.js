console.log('Visual Studio Code 로 코드 실행해보기 2');
var a = 5;
var b = 2;
console.log(a + b);