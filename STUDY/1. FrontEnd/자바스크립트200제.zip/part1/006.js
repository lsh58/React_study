(3 + 12) / 5
declaredVariable
greeting("Hello")