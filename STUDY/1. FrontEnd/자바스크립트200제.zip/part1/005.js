var name = "Peter"
var number = 200
var isTrue = true
var nothing = null
var empty = undefined
var list = []
var ref = {}
var func = function(){}