var result = true;
if (result) console.log('result 가 참 입니다.');
if (!result)
  console.log('실행되지 않습니다.');
if (result) {
  console.log('result 의 결과');
  console.log('>> 참 입니다.');
}
