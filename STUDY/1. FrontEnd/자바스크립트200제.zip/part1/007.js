// x 변수에 "a" 값을 할당하여 선언합니다.
var x = "a";
console.log(x); // 변수 x 를 console.log 로 출력합니다.

/*
x = "b";
console.log(x);
*/