1+12 // 13
x = 5
var foo = 'hello'
console.log(foo); // hello