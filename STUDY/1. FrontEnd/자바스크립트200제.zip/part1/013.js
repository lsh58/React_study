for (var i = 0; i < 10; i++) {
	console.log(i + '번째 반복 문장 입니다.');
}