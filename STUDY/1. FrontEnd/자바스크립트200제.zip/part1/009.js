var str = 'JavaScript';
var num = 200;
var arr = [1, 2, 3, 4, 5];
var obj = {a: 1, b: 2, c: 3};

console.log(str);
console.log(num);
console.log(arr);
console.log(obj);