function greeting() {
  "hello"
  "Chloe" + 3
  greeting()
}

greeting(if(true) { console.log("It is not acceptable") })