document.createElement('div');
var element_div = document.createElement('div');
element_div.id = 'div_name';
