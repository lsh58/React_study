var number = 2;
if (number == 1) {
  console.log('number 는 1 입니다');
} else if (number == 2) {
  console.log('number 는 2 입니다');
} else if (number == 3) {
  console.log('number 는 3 입니다');
} else {
  console.log('number 는 1,2,3 중 해당되는 것이 없습니다.');
}